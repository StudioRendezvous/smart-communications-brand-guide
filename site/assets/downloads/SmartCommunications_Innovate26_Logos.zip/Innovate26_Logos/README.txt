Innovate26 logo and lockups (from the Innovate sub-branding board)

Logos: Blue (Industry navy wordmark) for white and light backgrounds; Dark (Tiber #0E2030 wordmark, the SMART logo's own color) for white and light backgrounds next to the SMART logo; White for navy, dark and photographic backgrounds.
Lockups: Chicago 4/15-4/17, Save the Date and Register Now in Blue and White; London in White.

SVG for design and web; transparent PNG (2000 px wide) for PowerPoint, Word and email.
Use for Innovate materials only. Don't recolor, stretch or separate the cloud from the wordmark.
