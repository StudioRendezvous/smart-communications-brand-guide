Innovate 26 logo

Dark version: for white and light backgrounds.
White version: for navy, dark and photographic backgrounds.

Vector SVG for design and web; transparent PNG (2000 px wide) for PowerPoint, Word and email.
Use for Innovate materials only. Don't recolor, stretch or separate the cloud from the wordmark.
