SMART COMMUNICATIONS — LOGO PACK (2026)
========================================

SVG = vector, for design tools, web and print. PNG = 2000 px wide, transparent, for PowerPoint, Word and email.

WHICH FILE
- Light backgrounds: the "Dark" files (Tiber #0E2030 wordmark)
- Navy, dark or photographic backgrounds: the "White" files
- Tagline "Scale the Conversation(TM)": Blue on light, Mono where color is not available. Never gold.
- Conversation Cloud(TM): the platform mark. It is not a product wordmark and never the AI icon.
- Product logos are monotone: SmartIQ, SmartCOMM, SmartPATH, SmartHUB. SmartDX has no lockup - set the name in type.

RULES
- Clear space around the logo = the height of the chevron
- Minimum size: 25 mm wide in print, 50 px wide on screen
- Do not stretch, recolor, outline, add shadows or glows, rotate or crop
- Do not change the spacing between the wordmark and the chevron
- Retired: the yellow / gold-chevron logo and all colored (yellow, teal, red, green, purple) product logos

Full guidance: The SMART Brand Guide (Logo & Use Guidance, Trademarks & Branded Terms).
